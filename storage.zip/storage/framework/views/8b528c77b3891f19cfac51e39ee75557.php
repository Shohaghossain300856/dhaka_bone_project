

<?php $__env->startSection('content'); ?>
    <deliveryreport></deliveryreport>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nsmlimited/mmc.nsmlimited.com/resources/views/backend/reports/deliveryReport.blade.php ENDPATH**/ ?>