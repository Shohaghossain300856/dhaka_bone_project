

<?php $__env->startSection('content'); ?>
<preorder
    :permissions='<?php echo json_encode($permissions, 15, 512) ?>'
    :roles='<?php echo json_encode($roles, 15, 512) ?>'
></preorder>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nsmlimited/mmc.nsmlimited.com/resources/views/backend/PreOrder/PreOrderIndex.blade.php ENDPATH**/ ?>