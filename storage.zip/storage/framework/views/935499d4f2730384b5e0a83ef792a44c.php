<?php $__env->startSection("title"); ?> | <?php echo e($page_title); ?> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <dashboard></dashboard>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nsmlimited/mmc.nsmlimited.com/resources/views/backend/dashboard/welcome.blade.php ENDPATH**/ ?>