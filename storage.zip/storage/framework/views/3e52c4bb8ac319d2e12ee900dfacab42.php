<?php $__env->startSection("title"); ?> | <?php echo e($page_title); ?> <?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/vendor/libs/datatables-bs5/datatables.bootstrap5.css" />
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.css" />
    <link rel="stylesheet" href="<?php echo e(asset('backend')); ?>/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.css" />

<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <!-- Title -->
                <h5 class="card-title mb-0"><?php echo e($page_title); ?></h5>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>
                <!-- Button Group -->
                <div class="dt-action-buttons">
                    <div class="dt-buttons btn-group">
                        <!-- Create Button -->
                        <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary create-new waves-effect waves-light">
                            <span>
                                <i class="ti ti-plus me-1"></i>
                                <span class="d-none d-sm-inline-block">Add New</span>
                            </span>
                        </a>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <div class="card-datatable text-nowrap">
		<div class="table-responsive mb-3">
                <table class="table custom-datatable border-top">
                    <thead>
                    <tr>
                        <th>Sl</th>
                        <th>Permission</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><span
                                class="user-popover"
                                data-bs-toggle="popover"
                                data-bs-trigger="hover"
                                data-bs-placement="top"
                                data-bs-html="true"
                                data-bs-content="
                                   <p><strong>Permissions:</strong></p>
                                    <?php $__currentLoopData = $user->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($permission->name); ?><br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                ">
                                <?php echo e($user->name); ?>

                            </span></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->phone); ?></td>
                            <td><?php echo e($user->roles->pluck('name')); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($user->status == 1 ? 'success' : 'danger'); ?>"><?php echo e($user->status ? 'Active' : 'Deactivated'); ?></span>
                            </td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-edit')): ?>
                                    <a href="<?php echo e(route('user.edit',$user)); ?>" class="btn btn-warning"><i class="fas fa-edit"></i></a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('permission-delete')): ?>
                                    <button type="button"  data-id="<?php echo e($user->id); ?>" class="btn btn-danger delete_button" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- Add more rows as required -->
                    </tbody>
                </table>
		</div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- Modal Header -->
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Confirm Action</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <!-- Modal Body -->
                <div class="modal-body">
                    Are you sure you want to proceed with this action?
                </div>
                <!-- Modal Footer -->
                <div class="modal-footer">
                    <form action="<?php echo e(route('user.destroy', 0)); ?>" method="POST" id="deleteForm">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <input type="hidden" name="id" id="delete_id" class="delete_id" value="0">
                        <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                        <button type="submit" class="btn btn-danger deleteButton"><i class="fa fa-trash"></i> DELETE</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('backend')); ?>/vendor/libs/datatables-bs5/datatables-bootstrap5.js"></script>
<script src="<?php echo e(asset('backend')); ?>/vendor/libs/datatables-bs5/custom-datatable5.js"></script>

<script>
    $(document).ready(function () {
        $(document).on("click", '.delete_button', function (e) {
            var id = $(this).data('id');
            var url = '<?php echo e(route("user.destroy",":id")); ?>';
            url = url.replace(':id',id);
            $("#deleteForm").attr("action",url);
            $("#delete_id").val(id);
        });
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Initialize all popovers
        var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
        popoverTriggerList.map(function (popoverTriggerEl) {
            return new bootstrap.Popover(popoverTriggerEl);
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nsmlimited/mmc.nsmlimited.com/resources/views/backend/user/index.blade.php ENDPATH**/ ?>