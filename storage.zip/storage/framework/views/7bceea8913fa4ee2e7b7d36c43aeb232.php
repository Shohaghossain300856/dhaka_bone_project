<!doctype html>
<?php
    $baseurl = url('/');
?>
<html
    lang="en"
    class="light-style layout-wide customizer-hide"
    dir="ltr"
    data-theme="theme-default"
    data-assets-path="<?php echo e($baseurl.'/'.'backend/'); ?>"
    data-template="vertical-menu-template">
<head>
    
     <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta charset="utf-8"/>
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"/>

    <title><?php echo e(config('app.name')); ?></title>

    <meta name="description" content=""/>

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset("favicon.png")); ?>"/>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com"/>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
    <link
        href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&ampdisplay=swap"
        rel="stylesheet"/>

    <!-- Icons -->
    <link rel="stylesheet" href="<?php echo e($baseurl); ?>/backend/vendor/fonts/fontawesome.css"/>
    <link rel="stylesheet" href="<?php echo e($baseurl); ?>/backend/vendor/fonts/tabler-icons.css"/>
    <link rel="stylesheet" href="<?php echo e($baseurl); ?>/backend/vendor/fonts/flag-icons.css"/>

    <!-- Core CSS -->
    <link rel="stylesheet" href="<?php echo e($baseurl); ?>/backend/vendor/css/rtl/core.css" class="template-customizer-core-css"/>
    <link rel="stylesheet" href="<?php echo e($baseurl); ?>/backend/css/demo.css"/>
    <link rel="stylesheet" href="<?php echo e($baseurl.'/backend/vendor/css/rtl/theme-default.css'); ?>"
          class="template-customizer-theme-css"/>
    <link rel="stylesheet" href="<?php echo e($baseurl.'/backend/vendor/libs/node-waves/node-waves.css'); ?>"/>
    <link rel="stylesheet" href="<?php echo e($baseurl.'/backend/vendor/css/rtl/core.css'); ?>" class="template-customizer-core-css"/>
    <link rel="stylesheet" href="<?php echo e($baseurl.'/backend/vendor/libs/perfect-scrollbar/perfect-scrollbar.css'); ?>"/>
    <link rel="stylesheet" href="<?php echo e($baseurl.'/backend/vendor/libs/typeahead-js/typeahead.css'); ?>"/>

    <script src="<?php echo e($baseurl.'/backend/vendor/js/helpers.js'); ?>"></script>
    <script src="<?php echo e($baseurl.'/backend/vendor/js/template-customizer.js'); ?>"></script>
    <script src="<?php echo e($baseurl.'/backend/js/config.js'); ?>"></script>


    <link rel="stylesheet" href="<?php echo e($baseurl); ?>/backend/vendor/css/pages/page-auth.css"/>
    <!-- alert css -->
    <link rel="stylesheet" href="<?php echo e($baseurl.'/backend/vendor/libs/sweetalert2/sweetalert2.css'); ?>"/>
    <!-- Helpers -->
    <script src="<?php echo e($baseurl); ?>/backend/vendor/js/helpers.js"></script>
    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Template customizer: To hide customizer set displayCustomizer value false in config.js.  -->
    <script src="<?php echo e($baseurl); ?>/backend/vendor/js/template-customizer.js"></script>
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->


    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css"
          href="https://cdn.datatables.net/buttons/2.4.1/css/buttons.dataTables.min.css">
    <script src="<?php echo e($baseurl); ?>/backend/js/config.js"></script>
    <link rel="stylesheet" type="text/css" href="registrationcss.style.css">
</head>

<body>
<!-- Content -->

<div class="container-xxl">
    <div class="authentication-wrapper authentication-basic container-p-y">
        <div class="authentication-inner py-4">

            <?php echo $__env->yieldContent('content'); ?>

        </div>
    </div>
</div>

<script src="<?php echo e($baseurl); ?>/backend/vendor/libs/jquery/jquery.js"></script>
<script src="<?php echo e($baseurl); ?>/backend/vendor/js/bootstrap.js"></script>

<!-- Main JS -->
<script src="<?php echo e($baseurl); ?>/backend/js/main.js"></script>

<?php echo $__env->yieldPushContent('script'); ?>
<!-- alert js -->
<script src="<?php echo e($baseurl.'/backend/vendor/libs/sweetalert2/sweetalert2.js'); ?>"></script>
<script src="<?php echo e($baseurl.'/backend/js/extended-ui-sweetalert2.js'); ?>"></script>
<script src="<?php echo e($baseurl.'/js/app.js'); ?>"></script>

<!-- alert fire -->
<?php if(session()->has('success')): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            Swal.fire({
                title: 'Success!',
                text: '<?php echo e(session('success')); ?>',
                icon: 'success',
                timer: 2000,
                timerProgressBar: true,
                showConfirmButton: false // Hides the "OK" button

            });
        });
    </script>
<?php endif; ?>
<?php if(session()->has('error')): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            Swal.fire({
                title: 'Error!',
                text: '<?php echo e(session('error')); ?>',
                icon: 'error',
                showConfirmButton: true,
                confirmButtonText: 'OK',
                confirmButtonColor: '#3085d6', // Optional: Customize the color of the OK button
                showCancelButton: true,
                cancelButtonText: 'Cancel',
                cancelButtonColor: '#d33',
            });
        });
    </script>
<?php endif; ?>
<?php if(session()->has('warning')): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            Swal.fire({
                title: 'warning!',
                text: '<?php echo e(session('warning')); ?>',
                icon: 'warning',
                showConfirmButton: true,
                confirmButtonText: 'OK',
                confirmButtonColor: '#3085d6', // Optional: Customize the color of the OK button
                showCancelButton: true,
                cancelButtonText: 'Cancel',
                cancelButtonColor: '#d33',

            });
        });
    </script>
<?php endif; ?>
</body>
</html>
<?php /**PATH /home/nsmlimited/mmc.nsmlimited.com/resources/views/layouts/app.blade.php ENDPATH**/ ?>