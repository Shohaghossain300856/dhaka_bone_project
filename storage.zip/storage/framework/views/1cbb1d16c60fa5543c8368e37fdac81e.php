
<?php $__env->startSection('content'); ?>
<unusablecondemnationlists></unusablecondemnationlists>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nsmlimited/mmc.nsmlimited.com/resources/views/backend/reports/unusable-condemnation-list.blade.php ENDPATH**/ ?>