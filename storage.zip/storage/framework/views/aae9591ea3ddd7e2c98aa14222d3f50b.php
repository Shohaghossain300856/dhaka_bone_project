<!DOCTYPE html>
<html lang="bn">
<head>
  <meta charset="UTF-8">
  <title>চাহিদাপত্র – A4</title>

  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Bengali:wght@400;500;600;700&display=swap" rel="stylesheet">

  <style>
    *{ margin:0;padding:0;box-sizing:border-box; }

    @page {
      size: A4 landscape;
      margin: 10mm;
    }

    body {
      margin: 0;
      padding: 15px;
      font-family: "Noto Sans Bengali", sans-serif;
      background: #f4f4f4;
      color: #000;
    }

    .page {
      width: 1080px;
      padding: 10mm;
      background: #fff;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      margin: auto;

      /* ✅ Footer bottom fix */
      display: flex;
      flex-direction: column;
    }

    .page-content{
      flex: 1 1 auto;
    }

    /* ✅ Print Button */
    .print-btn-wrap{
      text-align: right;
      margin-bottom: 10px;
    }
    .print-btn{
      background: #2563eb;
      color: #fff;
      border: none;
      padding: 8px 18px;
      font-size: 14px;
      border-radius: 6px;
      cursor: pointer;
      box-shadow: 0 2px 6px rgba(0,0,0,.2);
    }
    .print-btn:hover{ background: #1e40af; }

    /* Header */
    .header-section { 
      width: 33%; 
      font-size: 14px; 
      line-height: 1.5; 
    }
    .header-center { 
      text-align: center; 
      font-size: 19px; 
      font-weight: 700; 
      width: 34%;
    }
    .header-right { 
      text-align: right; 
      font-size: 14px; 
    }

    .header-row {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 15px;
    }

    .dotted-line {
      display: inline-block;
      min-width: 130px;
      border-bottom: 1px solid #000;
      margin-left: 5px;
    }

    .sub-title {
      text-align: center;
      font-weight: 500;
      margin: 15px 0 20px;
      font-size: 15px;
      line-height: 1.6;
    }

    .dotted-line-long { min-width: 250px; margin: 0 8px; }

    /* Table Style */
    table {
      width: 100%;
      border-collapse: collapse;
      table-layout: fixed;
    }

    th, td {
      border: 1px solid #000;
      padding: 6px 4px;
      text-align: center;
      word-break: break-word;
      vertical-align: middle;
      font-size: 13px;
    }

    th {
      background-color: #f8f8f8 !important;
      font-weight: 600;
      font-size: 12px;
    }

    td:nth-child(2) {
      text-align: left;
      padding-left: 8px;
      font-weight: 500;
    }

    /* Signature Section */
    .footer-sign-row {
      display: flex;
      justify-content: space-between;
      margin-top: auto; /* ✅ push to bottom */
      padding-top: 18px;
      break-inside: avoid;
      page-break-inside: avoid;
    }

    .sign-box { 
      width: 18%; 
      text-align: center;
    }

    .sign-label {
      font-weight: 600;
      margin-bottom: 10px;
      font-size: 13px;
      border-bottom: 1px solid #000;
      padding-bottom: 3px;
    }

    .sign-field {
      display: flex;
      align-items: center;
      gap: 4px;
      margin-top: 8px;
      font-size: 12px;
    }

    .dotted-small {
      flex: 1;
      border-bottom: 1px dotted #000;
      height: 14px;
    }

    /* ✅ row break safety */
    tbody tr { break-inside: avoid; page-break-inside: avoid; }

    /* ✅ MAKE EACH .page ONE PRINT PAGE + FOOTER LAST PAGE ONLY */
    @media print {
      body { background: none; margin: 0; padding: 0; }
      .page { box-shadow: none; width: 100%; margin: 0; }

      /* ✅ A4 landscape usable height (210mm - margins 20mm = 190mm) */
      .page{
        height: 190mm;
        page-break-after: always;
      }
      .page:last-child{
        page-break-after: auto;
      }

      th { background-color: #f8f8f8 !important; -webkit-print-color-adjust: exact; }

      /* ✅ Print button hide */
      .print-btn-wrap{ display: none !important; }
    }

    @media screen {
      .page{
        min-height: 190mm;
      }
    }
  </style>
</head>

<body>

<?php
  function bn_num($value){
      if($value === null) return '';
      $value = (string)$value;
      $en = ['0','1','2','3','4','5','6','7','8','9'];
      $bn = ['০','১','২','৩','৪','৫','৬','৭','৮','৯'];
      return str_replace($en, $bn, $value);
  }

  function num_fmt_bn($v){
      if($v === null || $v === '') return '';
      if(is_numeric($v)){
          $f = (float)$v;
          if(floor($f) == $f) return bn_num((string)(int)$f);
          $formatted = rtrim(rtrim(number_format($f, 2, '.', ''), '0'), '.');
          return bn_num($formatted);
      }
      return bn_num($v);
  }

  $memoNo = $preOrder->memo_no ?? '....................';

  $dateBn = $preOrder->date
      ? bn_num(\Carbon\Carbon::parse($preOrder->date)->format('d-m-Y'))
      : '....................';

  /* ✅ PAGINATION / CHUNKING FOR PRINT */
  $allItems = collect($preOrder->items ?? []);
  $perPage = 10; // ✅ change 10/11/12 based on your table height
  $pages = $allItems->chunk($perPage);
  $totalPages = $pages->count();

  /* ✅ if no items, still show one page */
  if($totalPages === 0){
    $pages = collect([collect([])]);
    $totalPages = 1;
  }
?>


<?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pIndex => $pageItems): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
  $isLastPage = ($pIndex === $totalPages - 1);
  $serialStart = $pIndex * $perPage;
?>

<div class="page">

    <!-- ✅ Print Button only first page -->
    <?php if($pIndex === 0): ?>
    <div class="print-btn-wrap">
      <button class="print-btn" onclick="window.print()">🖨️ Print A4</button>
    </div>
    <?php endif; ?>

    <div class="page-content">

      <div class="header-row">
        <div class="header-section">
          বরাবর,<br>
          <strong>অধ্যক্ষ</strong><br>
          ময়মনসিংহ মেডিকেল কলেজ<br>
          ময়মনসিংহ
        </div>

        <div class="header-section header-center">
          ময়মনসিংহ মেডিকেল কলেজ, ময়মনসিংহ
        </div>

        <div class="header-section header-right">
          ফরমাস নং : <span class="dotted-line"><?php echo e(bn_num($memoNo)); ?></span><br>
          তারিখ : <span class="dotted-line"><?php echo e($dateBn); ?></span>
        </div>
      </div>

      <!-- ✅ Subtitle only first page (optional) -->
      <?php if($pIndex === 0): ?>
      <div class="sub-title">
        অত্র মেডিকেল কলেজের
        <span class="dotted-line dotted-line-long">
          <?php echo e($preOrder->users?->departmentModel?->department_name_bn ?? '....................'); ?>

        </span>
        সরকারি কাজে ব্যবহারের নিমিত্তে নিম্নোক্ত দ্রব্য সরবরাহ করার জন্য অনুরোধ করা হলো।
      </div>
      <?php endif; ?>

      <table>
        <colgroup>
          <col style="width:5%;">   
          <col style="width:25%;">  
          <col style="width:12%;">   
          <col style="width:12%;">   
          <col style="width:10%;">   
          <col style="width:10%;">   
          <col style="width:10%;">   
          <col style="width:11%;">   
          <col style="width:5%;">  
        </colgroup>

        <thead>
          <tr>
            <th>ক্রমিক<br><?php echo e(bn_num(1)); ?></th>
            <th>দ্রব্যের নাম / বিবরণী<br><?php echo e(bn_num(2)); ?></th>
            <th>চাহিদার পরিমাণ<br>(অংকে ও কথায়)<br><?php echo e(bn_num(3)); ?></th>
            <th>অতিরিক্ত/পরিবর্তন<br>রূপে<br><?php echo e(bn_num(4)); ?></th>
            <th>বর্তমান মজুদ<br>(অংকে ও কথায়)<br><?php echo e(bn_num(5)); ?></th>
            <th>পূর্বে সরবরাহ<br>(অংকে ও কথায়)<br><?php echo e(bn_num(6)); ?></th>
            <th>পূর্বের ফরমাস<br>নং ও তারিখ<br><?php echo e(bn_num(7)); ?></th>
            <th>সরবরাহের পরিমাণ<br>(অংকে ও কথায়)<br><?php echo e(bn_num(8)); ?></th>
            <th>মন্তব্য<br><?php echo e(bn_num(9)); ?></th>
          </tr>
        </thead>

        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $pageItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <?php
            $productName = optional($item->product)->product ?? '....................';

            $demanded    = num_fmt_bn($item->qty ?? '');
            $modify      = num_fmt_bn($item->modify ?? '');

            $modifys     = ($item->modify !== null && $item->modify !== '') ? $modify : $demanded;

            $action      = $item->action_type ?? '';
            $actionBn    = $action === 'addition' ? 'অতিরিক্তরূপে' : ($action === 'replace' ? 'পরিবর্তনরূপে' : '');
          ?>
          <tr>
            <td><?php echo e(bn_num($serialStart + $i + 1)); ?></td>
            <td><?php echo e($productName); ?></td>
            <td><?php echo e($demanded); ?></td>
            <td><?php echo e($actionBn); ?></td>
            <td></td><td></td><td></td>
            <td><?php echo e($modifys); ?></td>
            <td></td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td><?php echo e(bn_num(1)); ?></td>
            <td style="color:#ccc;">দ্রব্যের নাম</td>
            <td></td><td></td><td></td><td></td><td></td><td></td><td></td>
          </tr>
        <?php endif; ?>
        </tbody>
      </table>

    </div><!-- /page-content -->

    <!-- ✅ Footer ONLY ON LAST PAGE -->
    <?php if($isLastPage): ?>
    <div class="footer-sign-row">
      <?php $__currentLoopData = ['চাহিদাকারী কর্মকর্তা', 'বিভাগীয় প্রধান', 'অধ্যক্ষ / উপাধ্যক্ষ', 'সচিব', 'স্টোর কিপার']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="sign-box">
        <div class="sign-label"><?php echo e($label); ?></div>
        <div class="sign-field">স্বাক্ষর: <span class="dotted-small"></span></div>
        <div class="sign-field">তারিখ: <span class="dotted-small"></span></div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>

</div><!-- /page -->

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</body>
</html><?php /**PATH /home/nsmlimited/mmc.nsmlimited.com/resources/views/backend/PreOrder/pre-order-show.blade.php ENDPATH**/ ?>