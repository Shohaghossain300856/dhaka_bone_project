
<?php $__env->startSection('content'); ?>
<departmenthead  :permissions="<?php echo e(json_encode($permissions)); ?>" ></departmenthead>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nsmlimited/mmc.nsmlimited.com/resources/views/backend/Department-Head/index.blade.php ENDPATH**/ ?>