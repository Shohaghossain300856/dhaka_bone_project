

<?php $__env->startSection('content'); ?>
  <emptystockreport 
      :empty-stock-products='<?php echo json_encode($emptyStockProducts, 15, 512) ?>'
  ></emptystockreport>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nsmlimited/mmc.nsmlimited.com/resources/views/backend/reports/emptyStockProductReport.blade.php ENDPATH**/ ?>