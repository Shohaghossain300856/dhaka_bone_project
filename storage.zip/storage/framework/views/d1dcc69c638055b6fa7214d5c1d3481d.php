
<?php $__env->startSection('content'); ?>
  <fund :permissions="<?php echo e(json_encode($permissions)); ?>"></fund>
<?php $__env->stopSection(); ?>  
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nsmlimited/mmc.nsmlimited.com/resources/views/backend/Fund/index.blade.php ENDPATH**/ ?>