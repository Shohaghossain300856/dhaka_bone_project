
<?php $__env->startSection('content'); ?>
<stocklist></stocklist>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nsmlimited/mmc.nsmlimited.com/resources/views/backend/Stock/stockList.blade.php ENDPATH**/ ?>