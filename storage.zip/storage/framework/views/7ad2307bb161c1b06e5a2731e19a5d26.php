
<?php $__env->startSection('content'); ?>
<supplier :permissions="<?php echo e(json_encode($permissions)); ?>"></supplier>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nsmlimited/mmc.nsmlimited.com/resources/views/backend/Supplier/index.blade.php ENDPATH**/ ?>