<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Requisition Report</title>

    <!-- Official Bangla Font -->
    <link href="https://fonts.maateen.me/solaiman-lipi/font.css" rel="stylesheet">

    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }

        :root{
            --ink:#000;
            --border:#000;
            --paper:#fff;
            --bg:#f4f6f8;
        }

        body {
            font-family: 'SolaimanLipi', serif;
            background: var(--bg);
            padding: 14px;
            color: var(--ink);
            font-size: 13px;
            line-height: 1.6;
        }

        .print-btn-wrap{
            max-width: 900px;
            margin: 0 auto 10px;
            text-align: right;
        }

        .print-btn{
            padding: 6px 12px;
            font-weight: bold;
            font-size: 13px;
            background: #000;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .document {
            max-width: 900px;
            margin: 0 auto;
            background: var(--paper);
            padding: 30px 35px;
            box-shadow: 0 0 8px rgba(0,0,0,0.12);
        }

        .header {
            border-bottom: 2px solid var(--border);
            text-align: center;
            padding-bottom: 6px;
            margin-bottom: 8px;
        }

        .header h2 {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 3px;
        }

        .memo-section {
            margin: 10px 0;
            display: flex;
            justify-content: space-between;
            font-weight: bold;
            font-size: 13px;
        }

        .address-section {
            margin: 12px 0;
            font-size: 13px;
        }

        .ref-line{
            margin: 8px 0;
            font-weight: bold;
            font-size: 13px;
        }

        .subject {
            margin: 10px 0;
            font-weight: bold;
            font-size: 13px;
        }

        .content {
            margin: 10px 0;
            font-size: 13px;
            text-align: justify;
        }

        .group-title{
            font-weight: bold;
            margin: 10px 0 6px;
            font-size: 13px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 8px 0 12px;
            font-size: 13px;
        }

        thead th{
            background: #f3f3f3;
            font-weight: bold;
            padding: 6px;
            border: 1px solid var(--border);
            font-size: 13px;
        }

        tbody td{
            border: 1px solid var(--border);
            padding: 6px;
            text-align: center;
            font-size: 13px;
        }

        .td-left {
            text-align: left !important;
            padding-left: 8px !important;
        }

        .signature-section {
            margin-top: 40px;
            page-break-inside: avoid;
        }

        .signature-text {
            font-size: 13px;
            font-weight: bold;
        }

        /* PRINT PERFECT */
        @page{
            size: A4;
            margin: 12mm;
        }

        @media print {
            body { background: #fff; padding: 0; }
            .print-btn-wrap { display: none !important; }
            .document {
                max-width: 100%;
                width: 100%;
                box-shadow: none;
                padding: 0;
            }
            thead { display: table-header-group; }
            tr, td, th { page-break-inside: avoid; }
        }
    </style>
</head>

<body>

<div class="print-btn-wrap">
    <button class="print-btn" onclick="window.print()">Print</button>
</div>

<?php
    use Carbon\Carbon;

    $payload = json_decode($payloadJson ?? '{}', true);
    $indentOrder = $payload['indentOrder'] ?? [];
    $groups      = $payload['groups'] ?? [];

    function bn($value){
        $map = ['0'=>'০','1'=>'১','2'=>'২','3'=>'৩','4'=>'৪','5'=>'৫','6'=>'৬','7'=>'৭','8'=>'৮','9'=>'৯'];
        return strtr((string)$value, $map);
    }

    $mainDate = !empty($indentOrder['date'])
        ? bn(Carbon::parse($indentOrder['date'])->format('d/m/Y'))
        : '';

    $refDate = !empty($indentOrder['ref_date'])
        ? bn(Carbon::parse($indentOrder['ref_date'])->format('d/m/Y'))
        : '';
?>

<div class="document">

    <div class="header">
        <h2><?php echo e($indentOrder['users']['department']['department_name_bn'] ?? ''); ?> বিভাগ</h2>
        <h2>ময়মনসিংহ মেডিকেল কলেজ, ময়মনসিংহ</h2>
    </div>

    <div class="memo-section">
        <div>স্মারক নং: <?php echo e(bn($indentOrder['memo_no'] ?? '')); ?></div>
        <div>তারিখ: <?php echo e($mainDate); ?> ইং</div>
    </div>

    <div class="address-section">
        <strong>বরাবর,</strong><br>
        অধ্যক্ষ<br>
        ময়মনসিংহ মেডিকেল কলেজ, ময়মনসিংহ।
    </div>

    <div class="ref-line">
        সূত্র: স্মারক নং-<?php echo e(bn($indentOrder['ref_memo_no'] ?? '')); ?>

        &nbsp;&nbsp;&nbsp;
        তারিখ: <?php echo e($refDate); ?> ইং
    </div>

    <div class="subject">
        বিষয়: <?php echo e($indentOrder['indent_subject']['name'] ?? 'চাহিদাপত্র'); ?>

    </div>

    <div class="content">
        <strong>মহোদয়,</strong><br>
        <p style="text-indent: 30px;">
            উপযুক্ত বিষয় ও সূত্র মোতাবেক অত্র বিভাগে শিক্ষা ও গবেষণা কার্যক্রম সুষ্ঠুভাবে পরিচালনার জন্য নিম্নলিখিত মালামাল সমূহ প্রয়োজন।
        </p>
    </div>

    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <!--   <div class="group-title">
            <?php echo e($group['subcategory_name'] ?? ''); ?>

        </div> -->

        <table>
            <thead>
                <tr>
                    <th>ক্রমিক</th>
                    <th>পণ্যের নাম</th>
                    <th>একক</th>
                    <th>পরিমাণ</th>
                    <th>একক মূল্য</th>
                    <th>মোট মূল্য</th>
                    <th>মন্তব্য</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $group['items'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(bn($i+1)); ?></td>
                    <td class="td-left"><?php echo e($item['product']['product'] ?? ''); ?></td>
                    <td><?php echo e($item['product']['unit'] ?? ''); ?></td>
                    <td><?php echo e(bn($item['qty'] ?? 0)); ?></td>
                    <td><?php echo e(bn($item['price'] ?? 0)); ?></td>
                    <td><?php echo e(bn($item['total_price'] ?? 0)); ?></td>
                    <td><?php echo e($item['remarks'] ?? ''); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="content">
        ইহা আপনার সদয় অবগতি ও প্রয়োজনীয় ব্যবস্থা গ্রহণের জন্য প্রেরণ করা হইল।
    </div>

    <div class="signature-section">
        <div class="signature-text">
         <?php echo e($indentOrder['users']['designation'] ?? ''); ?><br>
            <?php echo e($indentOrder['users']['department']['department_name_bn'] ?? ''); ?> বিভাগ<br>
            ময়মনসিংহ মেডিকেল কলেজ
        </div>
    </div>

</div>

</body>
</html>
<?php /**PATH /home/nsmlimited/mmc.nsmlimited.com/resources/views/backend/requisitionApplication/requisition-application-show.blade.php ENDPATH**/ ?>