<footer class="content-footer footer bg-footer-theme">
    <div class="container-xxl">
        <div class="footer-container d-flex align-items-center justify-content-between py-4 flex-md-row flex-column">
            <div class="text-body">
                © <?php echo e(date('Y')); ?>, made with ❤️ by 
                <a href="https://nsmlimited.com" target="_blank" class="footer-link">
                    NSM Limited
                </a>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /home/nsmlimited/mmc.nsmlimited.com/resources/views/backend/layouts/partial/footer.blade.php ENDPATH**/ ?>