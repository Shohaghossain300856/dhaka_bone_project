<ul class="menu-inner py-1">
  
  <li class="menu-header small text-uppercase">
    <span class="menu-header-text">
      User Role: <?php echo e(implode(', ', auth()->user()->roles->pluck('name')->toArray())); ?>

    </span>
  </li>

  
  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['stock management'])): ?>
    <?php
      $stockOpen = request()->routeIs(
        'stock-create.*',
        'stock-reports.*',
        'stock-out.*',
        'stock-list.*',
        'excel-upload-product.*',
        'pre-order.*'
      );
    ?>



      
  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['requisition application management'])): ?>
    <li class="menu-item <?php echo e(request()->routeIs('requisition-application.*','indent-subject.*') ? 'active open' : ''); ?>">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons ti ti-shopping-cart"></i>
        <div data-i18n="Indent Order">Requisition</div>
      </a>

      <ul class="menu-sub">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('requisition-subject')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('indent-subject.index') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('indent-subject.index')); ?>" class="menu-link">
              <div data-i18n="Indent Subject">Requisition Subject</div>
            </a>
          </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('requisition-order')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('requisition-application.index') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('requisition-application.index')); ?>" class="menu-link">
              <div data-i18n="Indent Order List">Requisition Application</div>
            </a>
          </li>
        <?php endif; ?>
      </ul>
    </li>
  <?php endif; ?>
  

    <li class="menu-item <?php echo e($stockOpen ? 'active open' : ''); ?>">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons ti ti-package"></i>
        <div data-i18n="Stock">Stock</div>
      </a>

      <ul class="menu-sub">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stock-in')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('stock-create.index') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('stock-create.index')); ?>" class="menu-link">
              <div data-i18n="Stock In">Stock In</div>
            </a>
          </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('indent-order')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('pre-order.index') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('pre-order.index')); ?>" class="menu-link">
              <div data-i18n="Stock Out">Indent Order / Stock Out</div>
            </a>
          </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stock-record')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('stock-list.index') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('stock-list.index')); ?>" class="menu-link">
              <div data-i18n="Stock Record">Stock Record</div>
            </a>
          </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('excel-upload-stock-In')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('excel-upload-product.index') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('excel-upload-product.index')); ?>" class="menu-link">
              <div data-i18n="Excel Upload / Stock In">Excel Upload / Stock In</div>
            </a>
          </li>
        <?php endif; ?>
      </ul>
    </li>
  <?php endif; ?>

  
  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['product'])): ?>
    <li class="menu-item <?php echo e(request()->routeIs('product.*') ? 'active' : ''); ?>">
      <a href="<?php echo e(route('product.index')); ?>" class="menu-link">
        <i class="menu-icon tf-icons ti ti-layout-grid"></i>
        <div data-i18n="Product List">Product List</div>
      </a>
    </li>
  <?php endif; ?>

  
  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Supplier'])): ?>
    <li class="menu-item <?php echo e(request()->routeIs('Supplier.*') ? 'active' : ''); ?>">
      <a href="<?php echo e(route('Supplier.index')); ?>" class="menu-link">
        <i class="menu-icon tf-icons ti ti-truck-delivery"></i>
        <div data-i18n="Supplier">Supplier</div>
      </a>
    </li>
  <?php endif; ?>

  
  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Damaged Product'])): ?>
    <li class="menu-item <?php echo e(request()->routeIs('damaged-product.*') ? 'active' : ''); ?>">
      <a href="<?php echo e(route('damaged-product.index')); ?>" class="menu-link">
        <i class="menu-icon tf-icons ti ti-alert-octagon"></i>
        <div data-i18n="Damaged Product">Damaged Product</div>
      </a>
    </li>
  <?php endif; ?>

  
  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['report management'])): ?>
    <?php
      $reportsOpen = request()->routeIs(
        'stock-reports.*',
        'stock-ledger.*',
        'head-report.*',
        'almost-expired-Product.*',
        'delivery-report',
        'almost-product-expiry',
        'empty-stock-product-report',
        'product-expiry',
        'unusable-condemnation-list'
      );
    ?>

    <li class="menu-item <?php echo e($reportsOpen ? 'active open' : ''); ?>">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons ti ti-file-analytics"></i>
        <div data-i18n="Reports">Reports</div>
      </a>

      <ul class="menu-sub">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stock ledger')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('stock-ledger.*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('stock-ledger.index')); ?>" class="menu-link">
              <div data-i18n="Stock Ledger">Stock Ledger</div>
            </a>
          </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user overview')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('head-report.*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('head-report.index')); ?>" class="menu-link">
              <div data-i18n="Head Reports">User Overview</div>
            </a>
          </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('stock reports')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('stock-reports.*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('stock-reports.index')); ?>" class="menu-link">
              <div data-i18n="Entry Report">Entry Report</div>
            </a>
          </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delivery-report')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('delivery-report') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('delivery-report')); ?>" class="menu-link">
              <div data-i18n="Delivery Report">Delivery Report</div>
            </a>
          </li>
        <?php endif; ?>

   <!--      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Almost Product Expiry')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('almost-product-expiry') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('almost-product-expiry')); ?>" class="menu-link">
              <i class="ti ti-box-seam"></i>
              <div data-i18n="Almost out of stock product">Almost out of stock product</div>
            </a>
          </li>
        <?php endif; ?> -->

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Empty Stock Product Report')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('empty-stock-product-report') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('empty-stock-product-report')); ?>" class="menu-link">
              <div data-i18n="Out of Stock">Out of Stock</div>
            </a>
          </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('product-expiry-date')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('almost-expired-Product.*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('almost-expired-Product.index')); ?>" class="menu-link">
              <div data-i18n="Almost Expired product">Expired product</div>
            </a>
          </li>
        <?php endif; ?>

<!--         <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Product-Expiry')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('product-expiry') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('product-expiry')); ?>" class="menu-link">
              <div data-i18n="Expired Product Details">Expired Product Details</div>
            </a>
          </li>
        <?php endif; ?> -->

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Unusable-Condemnation-list')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('unusable-condemnation-list') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('unusable-condemnation-list')); ?>" class="menu-link">
              <div data-i18n="Unusable\Condemnation list">Unusable\Condemnation list</div>
            </a>
          </li>
        <?php endif; ?>
      </ul>
    </li>
  <?php endif; ?>

  
  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['fund management'])): ?>
    <?php
      $fundOpen = request()->routeIs('fund.*','catagories.*','subCatagories.*');
    ?>

    <li class="menu-item <?php echo e($fundOpen ? 'active open' : ''); ?>">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons ti ti-wallet"></i>
        <div data-i18n="Fund Setup">Fund Setup</div>
      </a>

      <ul class="menu-sub">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('fund')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('fund.*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('fund.index')); ?>" class="menu-link">
              <div data-i18n="Fund">Fund</div>
            </a>
          </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('catagories')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('catagories.*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('catagories.index')); ?>" class="menu-link">
              <div data-i18n="Categories">Categories</div>
            </a>
          </li>
        <?php endif; ?>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('subCatagories')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('subCatagories.*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('subCatagories.index')); ?>" class="menu-link">
              <div data-i18n="Subcategories">Subcategories</div>
            </a>
          </li>
        <?php endif; ?>
      </ul>
    </li>
  <?php endif; ?>

  
  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['setting-index','setting-create','setting-edit','setting-delete'])): ?>
    <li class="menu-item <?php echo e(request()->is('backend/setting/*') ? 'active open' : ''); ?>">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons ti ti-settings"></i>
        <div data-i18n="Basic Setting">Setting</div>
      </a>
      <ul class="menu-sub">
        <li class="menu-item <?php echo e(request()->segment(3) == 'web_setting' ? 'active' : ''); ?>">
          <a href="<?php echo e(route('setting.index', 'web_setting')); ?>" class="menu-link">
            <div data-i18n="Web Setting">Web Setting</div>
          </a>
        </li>
        <li class="menu-item <?php echo e(request()->segment(3) == 'logo_setting' ? 'active' : ''); ?>">
          <a href="<?php echo e(route('setting.index', 'logo_setting')); ?>" class="menu-link">
            <div data-i18n="Logo Setting">Logo Setting</div>
          </a>
        </li>
      </ul>
    </li>
  <?php endif; ?>



  
  <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['user-index','user-create','user-edit','user-delete',     'permission-index','permission-create','permission-edit','permission-delete',
    'role-index','role-create','role-edit','role-delete'  ])): ?>
    <?php
      $userOpen = request()->routeIs('user.index','user.create','user.edit');
    ?>

    <li class="menu-item <?php echo e($userOpen ? 'active open' : ''); ?>">
      <a href="javascript:void(0);" class="menu-link menu-toggle">
        <i class="menu-icon tf-icons ti ti-users"></i>
        <div data-i18n="User">User Management</div>
      </a>
      <ul class="menu-sub">
     <!--    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user-create')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('user.create') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('user.create')); ?>" class="menu-link">
              <div data-i18n="Add New">Add User</div>
            </a>
          </li>
        <?php endif; ?> -->

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['user-index','user-edit','user-delete'])): ?>
          <li class="menu-item <?php echo e(request()->routeIs('user.index') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('user.index')); ?>" class="menu-link">
              <div data-i18n="User List">User</div>
            </a>
          </li>
        <?php endif; ?>

          <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('department')): ?>
          <li class="menu-item <?php echo e(request()->routeIs('department-head.*') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('department-head.index')); ?>" class="menu-link">
              <div data-i18n="Department">Department</div>
            </a>
          </li>
        <?php endif; ?>

       <li class="menu-item <?php echo e(request()->routeIs('role.*') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('role.index')); ?>" class="menu-link">
            <div data-i18n="Role">Role</div>
          </a>
        </li>
        <li class="menu-item <?php echo e(request()->routeIs('permission.*') ? 'active' : ''); ?>">
          <a href="<?php echo e(route('permission.index')); ?>" class="menu-link">
            <div data-i18n="Permission">Permission</div>
          </a>
        </li>

      </ul>
    </li>
  <?php endif; ?>

</ul>

<?php /**PATH /home/nsmlimited/mmc.nsmlimited.com/resources/views/backend/layouts/partial/sidebar.blade.php ENDPATH**/ ?>