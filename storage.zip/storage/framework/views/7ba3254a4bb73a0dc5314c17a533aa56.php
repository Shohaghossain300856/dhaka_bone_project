<?php
    $baseurl = url('/');
?>
<!doctype html>
<html
      lang="en"
      class="light-style layout-navbar-fixed layout-menu-fixed layout-compact"
      dir="ltr"
      data-theme="theme-default"
      data-assets-path="<?php echo e($baseurl . '/backend/'); ?>"
      data-template="vertical-menu-template"
      data-style="light">

<head>
    <meta charset="utf-8" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
    <title><?php echo e($webSetting['title']); ?> <?php echo $__env->yieldContent('title', ''); ?></title>
    <meta name="description" content="" />
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e($baseurl . '/backend/img/favicon/favicon.ico'); ?>" />


    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
          href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&ampdisplay=swap"
          rel="stylesheet" />

    <!-- Icons -->
    <link rel="stylesheet" href="<?php echo e($baseurl . '/backend/vendor/fonts/fontawesome.css'); ?>" />
    <link rel="stylesheet" href="<?php echo e($baseurl . '/backend/vendor/fonts/tabler-icons.css'); ?>" />
    <!-- Core CSS -->
    <link rel="stylesheet" href="<?php echo e($baseurl . '/backend/vendor/css/rtl/core.css'); ?>" class="template-customizer-core-css" />
    <link rel="stylesheet" href="<?php echo e($baseurl . '/backend/css/demo.css'); ?>" />
    <?php echo $__env->yieldPushContent('vendor_style'); ?>
    <!-- alert css -->
    <link rel="stylesheet" href="<?php echo e($baseurl . '/backend/vendor/libs/sweetalert2/sweetalert2.css'); ?>" />

    <!-- Page css -->
    <?php echo $__env->yieldPushContent('style'); ?>
    <!-- Vendors CSS -->
    <link rel="stylesheet" href="<?php echo e($baseurl . '/backend/vendor/libs/perfect-scrollbar/perfect-scrollbar.css'); ?>" />
    <!-- Helpers -->
    <script src="<?php echo e($baseurl . '/backend/vendor/js/helpers.js'); ?>"></script>
    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->

    <!--? Template customizer: To hide customizer set displayCustomizer value false in config.js.  -->
    <script src="<?php echo e($baseurl . '/backend/vendor/js/template-customizer.js'); ?>"></script>

    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="<?php echo e($baseurl . '/backend/js/config.js'); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</head>

<body>
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            <!-- Menu -->
            <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
                <?php echo $__env->make('backend.layouts.partial.sidebarlogo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="menu-inner-shadow"></div>
                <!-- sidebar -->
                <?php echo $__env->make('backend.layouts.partial.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </aside>
            <!-- / Menu -->
            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->
                <?php echo $__env->make('backend.layouts.partial.topnavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- / Navbar -->
                <!-- Content wrapper -->
                <div class="content-wrapper" id="app">

                    <!-- Content -->
                    <?php echo $__env->yieldContent('content'); ?>
                    <!-- / Content -->
                    <!-- Footer -->
                    <?php echo $__env->make('backend.layouts.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- / Footer -->
                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>

        <!-- Drag Target Area To SlideIn Menu On Small Screens -->
        <div class="drag-target"></div>
    </div>
    <?php
        $version = '1.0.2'; // change this on every update
    ?>

<script src="<?php echo e($baseurl . '/backend/vendor/libs/jquery/jquery.js'); ?>?v=<?php echo e($version); ?>"></script>
<script src="<?php echo e($baseurl . '/backend/vendor/libs/popper/popper.js'); ?>?v=<?php echo e($version); ?>"></script>
<script src="<?php echo e($baseurl . '/backend/vendor/js/bootstrap.js'); ?>?v=<?php echo e($version); ?>"></script>

<script src="<?php echo e($baseurl . '/backend/vendor/libs/perfect-scrollbar/perfect-scrollbar.js'); ?>?v=<?php echo e($version); ?>"></script>
<script src="<?php echo e($baseurl . '/backend/vendor/js/menu.js'); ?>?v=<?php echo e($version); ?>"></script>

<?php echo $__env->yieldPushContent('vendor_js'); ?>

<script src="<?php echo e($baseurl . '/backend/js/main.js'); ?>?v=<?php echo e($version); ?>"></script>


<script src="<?php echo e($baseurl . '/js/app.js'); ?>?v=<?php echo e($version); ?>"></script>



    <!-- alert fire -->
    <?php if(session()->has('success')): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Success!',
                    text: '<?php echo e(session('success')); ?>',
                    icon: 'success',
                    timer: 2000,
                    timerProgressBar: true,
                    showConfirmButton: false // Hides the "OK" button

                });
            });
        </script>
    <?php endif; ?>
    <?php if(session()->has('error')): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'Error!',
                    text: '<?php echo e(session('error')); ?>',
                    icon: 'error',
                    timer: 2000,
                    timerProgressBar: true,
                    showConfirmButton: false // Hides the "OK" button

                });
            });
        </script>
    <?php endif; ?>
    <?php if(session()->has('warning')): ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    title: 'warning!',
                    text: '<?php echo e(session('warning')); ?>',
                    icon: 'warning',
                    timer: 2000,
                    timerProgressBar: true,
                    showConfirmButton: false // Hides the "OK" button

                });
            });
        </script>
    <?php endif; ?>

    <!-- Page JS -->
    <?php echo $__env->yieldPushContent('script'); ?>
</body>

</html>
<?php /**PATH /home/nsmlimited/mmc.nsmlimited.com/resources/views/backend/layouts/app.blade.php ENDPATH**/ ?>