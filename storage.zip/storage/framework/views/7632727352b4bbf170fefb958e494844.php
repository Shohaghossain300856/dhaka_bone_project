
<?php $__env->startSection('content'); ?>
<indentsubject :permissions="<?php echo e(json_encode($permissions)); ?>"></indentsubject>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/nsmlimited/mmc.nsmlimited.com/resources/views/backend/IndentSubject/index.blade.php ENDPATH**/ ?>